"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { Heart, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { useWishlist } from "@/lib/wishlist-context"
import { useToast } from "@/hooks/use-toast"
import { formatCurrency } from "@/lib/format-currency"

const bestSellers = [
  {
    id: 201,
    name: "Eternal Rose",
    description: "Our most beloved rose fragrance with notes of Bulgarian rose, peony, and amber",
    price: 139.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    rating: 4.9,
    reviews: 428,
  },
  {
    id: 202,
    name: "Midnight Blue",
    description: "A sophisticated blend of lavender, cedar, and dark vanilla for evening wear",
    price: 119.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    rating: 4.8,
    reviews: 356,
  },
  {
    id: 203,
    name: "Citrus Splash",
    description: "Vibrant blend of lemon, bergamot, and mandarin with a hint of mint",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    rating: 4.7,
    reviews: 312,
  },
  {
    id: 204,
    name: "Oud Royale",
    description: "Luxurious combination of rare oud, saffron, and rose for a regal experience",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    rating: 4.9,
    reviews: 275,
  },
]

export default function BestSellers() {
  const { addItem } = useCart()
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist()
  const { toast } = useToast()

  const handleAddToCart = (product: (typeof bestSellers)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: "50ml", // Default size
    })

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const handleToggleWishlist = (e: React.MouseEvent, product: (typeof bestSellers)[0]) => {
    e.preventDefault()
    e.stopPropagation()

    const isCurrentlyInWishlist = isInWishlist(product.id)

    if (isCurrentlyInWishlist) {
      removeFromWishlist(product.id)
      toast({
        title: "Removed from wishlist",
        description: `${product.name} has been removed from your wishlist.`,
      })
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        category: product.category,
      })
      toast({
        title: "Added to wishlist",
        description: `${product.name} has been added to your wishlist.`,
      })
    }
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
      {bestSellers.map((product) => (
        <Card key={product.id} className="overflow-hidden border-0 shadow-sm">
          <Link href={`/products/${product.id}`}>
            <div className="relative aspect-square">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform hover:scale-105"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 rounded-full bg-white/80 backdrop-blur-sm z-10"
                onClick={(e) => handleToggleWishlist(e, product)}
              >
                <Heart className={`h-5 w-5 ${isInWishlist(product.id) ? "fill-primary text-primary" : ""}`} />
                <span className="sr-only">{isInWishlist(product.id) ? "Remove from wishlist" : "Add to wishlist"}</span>
              </Button>
              <Badge className="absolute top-2 left-2" variant="default">
                Best Seller
              </Badge>
            </div>
          </Link>
          <CardContent className="pt-4">
            <Link href={`/products/${product.id}`} className="hover:underline">
              <div className="flex items-center gap-1 mb-1">
                <Star className="h-3.5 w-3.5 fill-primary text-primary" />
                <span className="text-sm font-medium">{product.rating}</span>
                <span className="text-xs text-muted-foreground">({product.reviews})</span>
              </div>
              <h3 className="font-medium text-lg mb-1">{product.name}</h3>
            </Link>
            <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="font-semibold font-ui text-foreground dark:text-white">{formatCurrency(product.price)}</div>
            <Button size="sm" onClick={() => handleAddToCart(product)}>
              Add to Cart
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

