"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { useWishlist } from "@/lib/wishlist-context"
import { useToast } from "@/hooks/use-toast"
import { formatCurrency } from "@/lib/format-currency"

// Mock product data - in a real app, you would fetch this from an API
const allProducts = {
  1: {
    id: 1,
    name: "Midnight Orchid",
    description: "A captivating floral fragrance with notes of orchid, vanilla, and amber",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    isNew: true,
  },
  2: {
    id: 2,
    name: "Ocean Breeze",
    description: "Fresh aquatic scent with citrus and woody undertones",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    isNew: false,
  },
  3: {
    id: 3,
    name: "Golden Amber",
    description: "Warm and sensual with notes of amber, sandalwood, and musk",
    price: 109.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    isNew: true,
  },
  4: {
    id: 4,
    name: "Velvet Rose",
    description: "Elegant rose fragrance with hints of peony and bergamot",
    price: 119.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    isNew: false,
  },
}

type RelatedProductsProps = {
  productIds: number[]
}

export default function RelatedProducts({ productIds }: RelatedProductsProps) {
  const { addItem } = useCart()
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist()
  const { toast } = useToast()

  const relatedProducts = productIds.map((id) => allProducts[id as keyof typeof allProducts]).filter(Boolean)

  const handleAddToCart = (product: (typeof allProducts)[keyof typeof allProducts]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: "50ml", // Default size
      quantity: 1,
    })

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const handleToggleWishlist = (product: (typeof allProducts)[keyof typeof allProducts], e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const isCurrentlyInWishlist = isInWishlist(product.id)

    if (isCurrentlyInWishlist) {
      removeFromWishlist(product.id)
      toast({
        title: "Removed from wishlist",
        description: `${product.name} has been removed from your wishlist.`,
      })
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        category: product.category,
      })
      toast({
        title: "Added to wishlist",
        description: `${product.name} has been added to your wishlist.`,
      })
    }
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
      {relatedProducts.map((product) => (
        <Card key={product.id} className="overflow-hidden border-0 shadow-sm">
          <Link href={`/products/${product.id}`}>
            <div className="relative aspect-square">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform hover:scale-105"
              />
              <Button
                variant={isInWishlist(product.id) ? "default" : "ghost"}
                size="icon"
                className="absolute top-2 right-2 rounded-full bg-white/80 backdrop-blur-sm z-10"
                onClick={(e) => handleToggleWishlist(product, e)}
              >
                <Heart className={`h-5 w-5 ${isInWishlist(product.id) ? "fill-current" : ""}`} />
                <span className="sr-only">Add to wishlist</span>
              </Button>
              {product.isNew && <Badge className="absolute top-2 left-2">New</Badge>}
            </div>
          </Link>
          <CardContent className="pt-4">
            <Link href={`/products/${product.id}`} className="hover:underline">
              <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
              <h3 className="font-medium text-lg mb-1">{product.name}</h3>
            </Link>
            <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="font-semibold font-ui text-foreground dark:text-white">{formatCurrency(product.price)}</div>
            <Button size="sm" onClick={() => handleAddToCart(product)}>
              Add to Cart
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

