"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Heart, Minus, Plus, Share, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { useWishlist } from "@/lib/wishlist-context"
import { useToast } from "@/hooks/use-toast"
import RelatedProducts from "./components/related-products"
import { formatCurrency } from "@/lib/format-currency"

// Update the products object to include the specific perfumes
const products = {
  1: {
    id: 1,
    name: "Haramain Amber Oud",
    description:
      "A luxurious oriental fragrance with rich amber, oud, and spicy notes. This opulent scent combines precious woods with warm vanilla and saffron for a truly royal experience. The opening is a captivating blend of saffron and bergamot, leading to a heart of rich amber and oud. The base notes of vanilla, sandalwood, and musk create a warm, lasting impression that's perfect for special occasions.",
    price: 159.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Unisex",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Saffron", "Bergamot", "Cinnamon"],
      heart: ["Amber", "Oud", "Rose"],
      base: ["Vanilla", "Sandalwood", "Musk"],
    },
    rating: 4.9,
    reviews: 156,
    relatedProducts: [2, 3, 9, 11],
  },
  2: {
    id: 2,
    name: "Ombre Nomad",
    description:
      "An exotic journey through the desert with notes of oud, benzoin, and date. This sophisticated fragrance evokes the mystique of Arabian nights with its warm, spicy character. The opening is a captivating blend of spices and citrus, leading to a heart of rich oud and benzoin. The base notes of date, vanilla, and amber create a warm, lasting impression that's perfect for evening wear.",
    price: 189.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Unisex",
    sizes: ["50ml", "100ml", "Travel Size"],
    notes: {
      top: ["Cardamom", "Ginger", "Bergamot"],
      heart: ["Oud", "Benzoin", "Incense"],
      base: ["Date", "Vanilla", "Amber"],
    },
    rating: 4.8,
    reviews: 124,
    relatedProducts: [1, 3, 9, 11],
  },
  3: {
    id: 3,
    name: "I Am The King",
    description:
      "A bold and charismatic fragrance with notes of sandalwood, vetiver, and leather. This commanding scent exudes confidence and sophistication for the modern gentleman. The opening is a fresh blend of citrus and spices, leading to a heart of rich woods and leather. The base notes of vetiver, amber, and musk create a masculine, lasting impression that's perfect for the confident man.",
    price: 129.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Men",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Bergamot", "Black Pepper", "Cardamom"],
      heart: ["Sandalwood", "Leather", "Cedar"],
      base: ["Vetiver", "Amber", "Musk"],
    },
    rating: 4.7,
    reviews: 98,
    relatedProducts: [1, 2, 5, 11],
  },
  4: {
    id: 4,
    name: "Orchid White",
    description:
      "An elegant floral fragrance with delicate notes of white orchid, jasmine, and vanilla. This refined scent captures the pure essence of rare white orchids for a truly feminine experience. The opening is a fresh blend of citrus and green notes, leading to a heart of white orchid and jasmine. The base notes of vanilla, musk, and sandalwood create a soft, lasting impression that's perfect for day or evening wear.",
    price: 149.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Women",
    sizes: ["30ml", "50ml", "100ml"],
    notes: {
      top: ["Bergamot", "Green Notes", "Peach"],
      heart: ["White Orchid", "Jasmine", "Lily of the Valley"],
      base: ["Vanilla", "Musk", "Sandalwood"],
    },
    rating: 4.8,
    reviews: 112,
    relatedProducts: [7, 10, 1, 6],
  },
  5: {
    id: 5,
    name: "Cedar & Sage",
    description: "Earthy and aromatic with notes of cedar, sage, and vetiver",
    price: 99.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Men",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Bergamot", "Sage", "Lemon"],
      heart: ["Cedar", "Cypress", "Lavender"],
      base: ["Vetiver", "Amber", "Musk"],
    },
    rating: 4.5,
    reviews: 87,
    relatedProducts: [2, 8, 11, 3],
  },
  6: {
    id: 6,
    name: "Citrus Bloom",
    description: "Bright and refreshing with notes of bergamot, lemon, and orange blossom",
    price: 79.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Unisex",
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    notes: {
      top: ["Bergamot", "Lemon", "Grapefruit"],
      heart: ["Orange Blossom", "Neroli", "Jasmine"],
      base: ["White Musk", "Cedar", "Vetiver"],
    },
    rating: 4.4,
    reviews: 76,
    relatedProducts: [12, 2, 8, 10],
  },
  7: {
    id: 7,
    name: "Vanilla Noir",
    description: "Rich and indulgent with notes of vanilla, tonka bean, and dark chocolate",
    price: 119.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Women",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Bergamot", "Pink Pepper", "Almond"],
      heart: ["Vanilla", "Tonka Bean", "Jasmine"],
      base: ["Dark Chocolate", "Patchouli", "Sandalwood"],
    },
    rating: 4.8,
    reviews: 132,
    relatedProducts: [1, 4, 10, 3],
  },
  8: {
    id: 8,
    name: "Mountain Pine",
    description: "Crisp and invigorating with notes of pine, fir, and eucalyptus",
    price: 89.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Men",
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    notes: {
      top: ["Pine", "Eucalyptus", "Mint"],
      heart: ["Fir Balsam", "Cedar", "Juniper"],
      base: ["Vetiver", "Moss", "Amber"],
    },
    rating: 4.5,
    reviews: 94,
    relatedProducts: [2, 5, 11, 6],
  },
  9: {
    id: 9,
    name: "Amber Oud",
    description: "Luxurious and exotic with notes of oud, amber, and spices",
    price: 149.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Unisex",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Saffron", "Cardamom", "Pink Pepper"],
      heart: ["Rose", "Oud", "Geranium"],
      base: ["Amber", "Sandalwood", "Patchouli", "Musk"],
    },
    rating: 4.9,
    reviews: 108,
    relatedProducts: [3, 11, 7, 1],
  },
  10: {
    id: 10,
    name: "Jasmine Dreams",
    description: "Delicate and romantic with notes of jasmine, lily, and white musk",
    price: 109.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Women",
    sizes: ["30ml", "50ml", "100ml"],
    notes: {
      top: ["Bergamot", "Peach", "Green Notes"],
      heart: ["Jasmine", "Lily", "Ylang-Ylang"],
      base: ["White Musk", "Vanilla", "Sandalwood"],
    },
    rating: 4.7,
    reviews: 89,
    relatedProducts: [1, 4, 7, 6],
  },
  11: {
    id: 11,
    name: "Spiced Leather",
    description: "Bold and sophisticated with notes of leather, spices, and tobacco",
    price: 129.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Men",
    sizes: ["50ml", "100ml"],
    notes: {
      top: ["Cardamom", "Cinnamon", "Nutmeg"],
      heart: ["Leather", "Tobacco", "Cedar"],
      base: ["Vanilla", "Amber", "Musk"],
    },
    rating: 4.8,
    reviews: 76,
    relatedProducts: [2, 5, 8, 9],
  },
  12: {
    id: 12,
    name: "Mediterranean Citrus",
    description: "Vibrant and sunny with notes of lemon, bergamot, and neroli",
    price: 84.99,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Unisex",
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    notes: {
      top: ["Lemon", "Bergamot", "Mandarin"],
      heart: ["Neroli", "Orange Blossom", "Petitgrain"],
      base: ["White Musk", "Cedar", "Amber"],
    },
    rating: 4.6,
    reviews: 68,
    relatedProducts: [6, 2, 3, 10],
  },
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const productId = Number.parseInt(params.id)
  const product = products[productId as keyof typeof products] || products[1]

  const [quantity, setQuantity] = useState(1)
  const [selectedSize, setSelectedSize] = useState(product.sizes[1] || product.sizes[0])
  const [selectedImage, setSelectedImage] = useState(0)
  const { addItem } = useCart()
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist()
  const { toast } = useToast()

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      quantity,
    })

    toast({
      title: "Added to cart",
      description: `${quantity} × ${product.name} (${selectedSize}) has been added to your cart.`,
    })
  }

  const handleBuyNow = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      quantity,
    })
  }

  const handleToggleWishlist = () => {
    const isCurrentlyInWishlist = isInWishlist(product.id)

    if (isCurrentlyInWishlist) {
      removeFromWishlist(product.id)
      toast({
        title: "Removed from wishlist",
        description: `${product.name} has been removed from your wishlist.`,
      })
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.images[0],
        category: product.category,
      })
      toast({
        title: "Added to wishlist",
        description: `${product.name} has been added to your wishlist.`,
      })
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product.name,
          text: `Check out this amazing fragrance: ${product.name}`,
          url: window.location.href,
        })
      } catch (error) {
        toast({
          title: "Sharing failed",
          description: "Could not share this product.",
          variant: "destructive",
        })
      }
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "Product link copied to clipboard.",
      })
    }
  }

  return (
    <div className="container py-10">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm mb-6">
        <Link href="/" className="text-muted-foreground hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="h-4 w-4 mx-2 text-muted-foreground" />
        <Link href="/products" className="text-muted-foreground hover:text-foreground">
          Products
        </Link>
        <ChevronRight className="h-4 w-4 mx-2 text-muted-foreground" />
        <Link
          href={`/products/category/${product.category.toLowerCase()}`}
          className="text-muted-foreground hover:text-foreground"
        >
          {product.category}
        </Link>
        <ChevronRight className="h-4 w-4 mx-2 text-muted-foreground" />
        <span>{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square relative rounded-lg overflow-hidden border">
            <Image
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>
          <div className="grid grid-cols-3 gap-4">
            {product.images.map((image, index) => (
              <button
                key={index}
                className={`aspect-square relative rounded-lg overflow-hidden border ${selectedImage === index ? "ring-2 ring-primary" : ""}`}
                onClick={() => setSelectedImage(index)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - Image ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div>
          <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>

          <div className="flex items-center gap-2 mb-4">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-muted-foreground"}`}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {product.rating} ({product.reviews} reviews)
            </span>
          </div>

          <div className="text-2xl font-bold font-ui text-foreground dark:text-white mb-6">
            {formatCurrency(product.price)}
          </div>

          <div className="mb-6">
            <h3 className="font-medium mb-2">Size</h3>
            <div className="flex gap-3">
              {product.sizes.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  className="rounded-full px-6"
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="font-medium mb-2">Quantity</h3>
            <div className="flex items-center">
              <Button variant="outline" size="icon" className="rounded-full" onClick={decreaseQuantity}>
                <Minus className="h-4 w-4" />
              </Button>
              <span className="mx-4 font-medium">{quantity}</span>
              <Button variant="outline" size="icon" className="rounded-full" onClick={increaseQuantity}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex gap-4 mb-8">
            <Button size="lg" className="flex-1" onClick={handleAddToCart}>
              Add to Cart
            </Button>
            <Button size="lg" variant="outline" className="flex-1" onClick={handleBuyNow} asChild>
              <Link href="/checkout">Buy Now</Link>
            </Button>
            <Button
              size="icon"
              variant={isInWishlist(product.id) ? "default" : "outline"}
              onClick={handleToggleWishlist}
            >
              <Heart className={`h-5 w-5 ${isInWishlist(product.id) ? "fill-current" : ""}`} />
            </Button>
            <Button size="icon" variant="outline" onClick={handleShare}>
              <Share className="h-5 w-5" />
            </Button>
          </div>

          <Separator className="my-6" />

          <Tabs defaultValue="description">
            <TabsList className="w-full">
              <TabsTrigger value="description" className="flex-1">
                Description
              </TabsTrigger>
              <TabsTrigger value="notes" className="flex-1">
                Notes
              </TabsTrigger>
              <TabsTrigger value="reviews" className="flex-1">
                Reviews
              </TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="pt-4">
              <p className="text-muted-foreground">{product.description}</p>
            </TabsContent>
            <TabsContent value="notes" className="pt-4">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Top Notes</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.notes.top.map((note) => (
                      <Badge key={note} variant="outline">
                        {note}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Heart Notes</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.notes.heart.map((note) => (
                      <Badge key={note} variant="outline">
                        {note}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Base Notes</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.notes.base.map((note) => (
                      <Badge key={note} variant="outline">
                        {note}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="pt-4">
              <p className="text-center text-muted-foreground py-8">Customer reviews will be displayed here.</p>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Related Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
        <RelatedProducts productIds={product.relatedProducts} />
      </div>
    </div>
  )
}

