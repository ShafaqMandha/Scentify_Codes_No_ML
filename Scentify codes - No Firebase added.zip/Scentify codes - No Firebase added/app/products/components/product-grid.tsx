"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { useToast } from "@/hooks/use-toast"
import type { FilterState } from "./product-filters"
import { useWishlist } from "@/lib/wishlist-context"
import { formatCurrency } from "@/lib/format-currency"

// Update the allProducts array to include the specific perfumes
const allProducts = [
  {
    id: 1,
    name: "Haramain Amber Oud",
    description:
      "A luxurious oriental fragrance with rich amber, oud, and spicy notes. This opulent scent combines precious woods with warm vanilla and saffron for a truly royal experience.",
    price: 159.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    scentFamily: ["Oriental", "Woody"],
    sizes: ["50ml", "100ml"],
    isNew: true,
  },
  {
    id: 2,
    name: "Ombre Nomad",
    description:
      "An exotic journey through the desert with notes of oud, benzoin, and date. This sophisticated fragrance evokes the mystique of Arabian nights with its warm, spicy character.",
    price: 189.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    scentFamily: ["Oriental", "Spicy"],
    sizes: ["50ml", "100ml", "Travel Size"],
    isNew: true,
  },
  {
    id: 3,
    name: "I Am The King",
    description:
      "A bold and charismatic fragrance with notes of sandalwood, vetiver, and leather. This commanding scent exudes confidence and sophistication for the modern gentleman.",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    scentFamily: ["Woody", "Aromatic"],
    sizes: ["50ml", "100ml"],
    isNew: false,
  },
  {
    id: 4,
    name: "Orchid White",
    description:
      "An elegant floral fragrance with delicate notes of white orchid, jasmine, and vanilla. This refined scent captures the pure essence of rare white orchids for a truly feminine experience.",
    price: 149.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    scentFamily: ["Floral", "Fresh"],
    sizes: ["30ml", "50ml", "100ml"],
    isNew: true,
  },
  {
    id: 5,
    name: "Cedar & Sage",
    description: "Earthy and aromatic with notes of cedar, sage, and vetiver",
    price: 99.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    scentFamily: ["Woody", "Fresh"],
    sizes: ["50ml", "100ml"],
    isNew: false,
  },
  {
    id: 6,
    name: "Citrus Bloom",
    description: "Bright and refreshing with notes of bergamot, lemon, and orange blossom",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    scentFamily: ["Citrus", "Floral"],
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    isNew: true,
  },
  {
    id: 7,
    name: "Vanilla Noir",
    description: "Rich and indulgent with notes of vanilla, tonka bean, and dark chocolate",
    price: 119.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    scentFamily: ["Oriental"],
    sizes: ["50ml", "100ml"],
    isNew: false,
  },
  {
    id: 8,
    name: "Mountain Pine",
    description: "Crisp and invigorating with notes of pine, fir, and eucalyptus",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    scentFamily: ["Fresh", "Woody"],
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    isNew: false,
  },
  {
    id: 9,
    name: "Amber Oud",
    description: "Luxurious and exotic with notes of oud, amber, and spices",
    price: 149.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    scentFamily: ["Oriental", "Woody"],
    sizes: ["50ml", "100ml"],
    isNew: true,
  },
  {
    id: 10,
    name: "Jasmine Dreams",
    description: "Delicate and romantic with notes of jasmine, lily, and white musk",
    price: 109.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Women",
    scentFamily: ["Floral"],
    sizes: ["30ml", "50ml", "100ml"],
    isNew: false,
  },
  {
    id: 11,
    name: "Spiced Leather",
    description: "Bold and sophisticated with notes of leather, spices, and tobacco",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Men",
    scentFamily: ["Woody", "Oriental"],
    sizes: ["50ml", "100ml"],
    isNew: false,
  },
  {
    id: 12,
    name: "Mediterranean Citrus",
    description: "Vibrant and sunny with notes of lemon, bergamot, and neroli",
    price: 84.99,
    image: "/placeholder.svg?height=400&width=300",
    category: "Unisex",
    scentFamily: ["Citrus", "Fresh"],
    sizes: ["30ml", "50ml", "100ml", "Travel Size"],
    isNew: true,
  },
]

type ProductGridProps = {
  filters: FilterState
  searchQuery?: string
}

export default function ProductGrid({ filters, searchQuery = "" }: ProductGridProps) {
  const { addItem } = useCart()
  const { toast } = useToast()
  const [filteredProducts, setFilteredProducts] = useState(allProducts)
  const [isFiltering, setIsFiltering] = useState(false)
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist()

  // Apply filters whenever they change
  useEffect(() => {
    setIsFiltering(true)

    // Simulate a slight delay for filtering to show loading state
    const timer = setTimeout(() => {
      const filtered = allProducts.filter((product) => {
        // Filter by search query
        if (
          searchQuery &&
          !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !product.description.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return false
        }

        // Filter by category
        if (filters.categories.length > 0 && !filters.categories.includes(product.category)) {
          return false
        }

        // Filter by scent family
        if (
          filters.scentFamilies.length > 0 &&
          !product.scentFamily.some((scent) => filters.scentFamilies.includes(scent))
        ) {
          return false
        }

        // Filter by size
        if (filters.sizes.length > 0 && !product.sizes.some((size) => filters.sizes.includes(size))) {
          return false
        }

        // Filter by price range
        if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
          return false
        }

        return true
      })

      setFilteredProducts(filtered)
      setIsFiltering(false)
    }, 300)

    return () => clearTimeout(timer)
  }, [filters, searchQuery])

  const handleAddToCart = (product: (typeof allProducts)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: product.sizes[1] || product.sizes[0], // Default to 50ml or first available size
    })

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  if (isFiltering) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="overflow-hidden border-0 shadow-sm">
            <div className="animate-pulse">
              <div className="aspect-square bg-muted"></div>
              <div className="p-4 space-y-3">
                <div className="h-4 bg-muted rounded w-1/4"></div>
                <div className="h-6 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-full"></div>
                <div className="h-4 bg-muted rounded w-full"></div>
                <div className="flex justify-between items-center pt-2">
                  <div className="h-6 bg-muted rounded w-1/4"></div>
                  <div className="h-9 bg-muted rounded w-1/3"></div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    )
  }

  if (filteredProducts.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium mb-2">No products found</h3>
        <p className="text-muted-foreground mb-6">
          Try adjusting your filters or search query to find what you're looking for.
        </p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Reset All Filters
        </Button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredProducts.map((product) => (
        <Card key={product.id} className="overflow-hidden border-0 shadow-sm">
          <Link href={`/products/${product.id}`}>
            <div className="relative aspect-square">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform hover:scale-105"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 rounded-full bg-white/80 backdrop-blur-sm z-10"
                onClick={(e) => {
                  e.stopPropagation()
                  e.preventDefault()

                  const isCurrentlyInWishlist = isInWishlist(product.id)

                  if (isCurrentlyInWishlist) {
                    removeFromWishlist(product.id)
                    toast({
                      title: "Removed from wishlist",
                      description: `${product.name} has been removed from your wishlist.`,
                    })
                  } else {
                    addToWishlist({
                      id: product.id,
                      name: product.name,
                      price: product.price,
                      image: product.image,
                      category: product.category,
                    })
                    toast({
                      title: "Added to wishlist",
                      description: `${product.name} has been added to your wishlist.`,
                    })
                  }
                }}
              >
                <Heart className={`h-5 w-5 ${isInWishlist(product.id) ? "fill-primary text-primary" : ""}`} />
                <span className="sr-only">{isInWishlist(product.id) ? "Remove from wishlist" : "Add to wishlist"}</span>
              </Button>
              {product.isNew && <Badge className="absolute top-2 left-2">New</Badge>}
            </div>
          </Link>
          <CardContent className="pt-4">
            <Link href={`/products/${product.id}`} className="hover:underline">
              <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
              <h3 className="font-medium text-lg mb-1">{product.name}</h3>
            </Link>
            <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="font-semibold font-ui text-foreground dark:text-white">{formatCurrency(product.price)}</div>
            <Button size="sm" onClick={() => handleAddToCart(product)}>
              Add to Cart
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

